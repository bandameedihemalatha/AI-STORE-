/**
 * filters.js — Filter state management and filtering logic
 *
 * FilterState holds the current active filters.
 * Call applyFilters() to re-render visibility based on state.
 */

const FilterState = {
  category: "all",   // "all" or a category id
  pricing: null,     // null | "free" | "freemium" | "paid"
  query: "",         // search string (lowercased)
};

/** Set active category and re-filter */
function setCategory(cat) {
  FilterState.category = cat;
  applyFilters();
}

/** Toggle a pricing filter on/off */
function togglePricing(price) {
  FilterState.pricing = FilterState.pricing === price ? null : price;
  applyFilters();
}

/** Update the search query and re-filter */
function setQuery(q) {
  FilterState.query = q.toLowerCase().trim();
  applyFilters();
}

/** Returns true if a tool should be visible given current FilterState */
function toolMatchesFilters(tool) {
  const { category, pricing, query } = FilterState;

  const catMatch   = category === "all" || tool.category === category;
  const priceMatch = !pricing  || tool.pricing === pricing;

  const searchTarget = [tool.name, tool.tagline, tool.description, tool.category]
    .join(" ")
    .toLowerCase();
  const searchMatch = !query || searchTarget.includes(query);

  return catMatch && priceMatch && searchMatch;
}

/** Apply filters: show/hide cards and category sections */
function applyFilters() {
  let visibleCount = 0;

  document.querySelectorAll(".tool-card").forEach((card) => {
    const toolId = card.dataset.toolId;
    const tool = TOOLS.find((t) => t.id === toolId);
    const visible = tool && toolMatchesFilters(tool);
    card.classList.toggle("hidden", !visible);
    if (visible) visibleCount++;
  });

  // Hide category sections that have no visible cards
  document.querySelectorAll(".category-section").forEach((section) => {
    const hasVisible = section.querySelectorAll(".tool-card:not(.hidden)").length > 0;
    section.style.display = hasVisible ? "" : "none";
  });

  // No-results message
  const noResults = document.getElementById("no-results");
  if (noResults) noResults.classList.toggle("show", visibleCount === 0);

  syncFilterUI();
}

/** Keep button active-states in sync with FilterState */
function syncFilterUI() {
  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.cat === FilterState.category);
  });

  document.querySelectorAll(".price-tag").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.price === FilterState.pricing);
  });
}
