/**
 * data.js — All AI tool & category definitions
 *
 * HOW TO ADD A NEW TOOL:
 * Add an object to the TOOLS array below. Fields:
 *
 *   id:          unique string (kebab-case)
 *   name:        display name
 *   tagline:     one-line description (shown under name)
 *   category:    must match an id in CATEGORIES
 *   pricing:     "free" | "freemium" | "paid"
 *   logo:        emoji used as icon
 *   description: 1–2 sentences shown on card
 *   plans:       array of { name, price, colorClass: "green"|"yellow"|"red" }
 *   links: {
 *     website:  string (required)
 *     ios:      string (optional — App Store URL)
 *     android:  string (optional — Play Store URL)
 *     noapp:    string (optional — shown if no ios/android)
 *   }
 *
 * HOW TO ADD A NEW CATEGORY:
 * Add an object to CATEGORIES below. The renderer picks it up automatically.
 */

const CATEGORIES = [
  { id: "chatbot",      label: "🤖 Chatbots",       icon: "🤖", color: "rgba(108,99,255,0.15)"  },
  { id: "writing",      label: "✍️ Writing",          icon: "✍️",  color: "rgba(67,230,181,0.12)"  },
  { id: "image",        label: "🎨 Image",             icon: "🎨",  color: "rgba(255,101,132,0.12)" },
  { id: "video",        label: "🎬 Video",             icon: "🎬",  color: "rgba(247,201,72,0.12)"  },
  { id: "coding",       label: "💻 Coding",            icon: "💻",  color: "rgba(108,99,255,0.12)"  },
  { id: "productivity", label: "⚡ Productivity",      icon: "⚡",  color: "rgba(67,230,181,0.12)"  },
  { id: "audio",        label: "🎵 Audio",             icon: "🎵",  color: "rgba(255,101,132,0.12)" },
  { id: "research",     label: "🔬 Research",          icon: "🔬",  color: "rgba(108,99,255,0.12)"  },
];

const TOOLS = [

  // ══════════════════════ CHATBOTS ══════════════════════
  {
    id: "chatgpt",
    name: "ChatGPT",
    tagline: "OpenAI's conversational AI",
    category: "chatbot",
    pricing: "freemium",
    logo: "🧠",
    description:
      "The world's most popular AI assistant. Write, code, analyze, brainstorm, and chat. GPT-4o available in free tier; Plus unlocks priority access and advanced features.",
    plans: [
      { name: "Free",  price: "$0/mo — GPT-4o limited",           colorClass: "green"  },
      { name: "Plus",  price: "$20/mo — GPT-4o priority + DALL·E", colorClass: "yellow" },
      { name: "Team",  price: "$30/user/mo",                        colorClass: "red"    },
    ],
    links: {
      website: "https://chat.openai.com",
      ios:     "https://apps.apple.com/app/chatgpt/id6448311069",
      android: "https://play.google.com/store/apps/details?id=com.openai.chatgpt",
    },
  },
  {
    id: "claude",
    name: "Claude",
    tagline: "Anthropic's AI assistant",
    category: "chatbot",
    pricing: "freemium",
    logo: "✦",
    description:
      "A powerful, safe, and helpful AI assistant by Anthropic. Excellent at analysis, writing, coding, and nuanced conversation. Known for long context and thoughtful responses.",
    plans: [
      { name: "Free", price: "$0/mo — Claude 3.5 Sonnet",   colorClass: "green"  },
      { name: "Pro",  price: "$20/mo — Priority + Projects", colorClass: "yellow" },
      { name: "Team", price: "$30/user/mo",                  colorClass: "red"    },
    ],
    links: {
      website: "https://claude.ai",
      ios:     "https://apps.apple.com/app/claude-by-anthropic/id6473753684",
      android: "https://play.google.com/store/apps/details?id=com.anthropic.claude",
    },
  },
  {
    id: "gemini",
    name: "Google Gemini",
    tagline: "Google's multimodal AI",
    category: "chatbot",
    pricing: "freemium",
    logo: "💠",
    description:
      "Google's flagship AI assistant with deep integration into Google Workspace. Multimodal capabilities with text, image, and document understanding.",
    plans: [
      { name: "Free",     price: "$0/mo — Gemini 1.5 Flash",  colorClass: "green"  },
      { name: "Advanced", price: "$19.99/mo — Gemini 1.5 Pro", colorClass: "yellow" },
    ],
    links: {
      website: "https://gemini.google.com",
      ios:     "https://apps.apple.com/app/google-gemini/id6477489606",
      android: "https://play.google.com/store/apps/details?id=com.google.android.apps.bard",
    },
  },
  {
    id: "perplexity",
    name: "Perplexity AI",
    tagline: "AI-powered search engine",
    category: "chatbot",
    pricing: "freemium",
    logo: "🔎",
    description:
      "AI search assistant that gives cited, real-time answers. Great for research, fact-checking, and finding sources. Combines web search with LLM reasoning.",
    plans: [
      { name: "Free", price: "$0/mo — Basic search",      colorClass: "green"  },
      { name: "Pro",  price: "$20/mo — GPT-4, unlimited", colorClass: "yellow" },
    ],
    links: {
      website: "https://www.perplexity.ai",
      ios:     "https://apps.apple.com/app/perplexity-ask-anything/id1668000334",
      android: "https://play.google.com/store/apps/details?id=ai.perplexity.app.android",
    },
  },
  {
    id: "copilot-chat",
    name: "Microsoft Copilot",
    tagline: "Microsoft's free AI assistant",
    category: "chatbot",
    pricing: "free",
    logo: "🪟",
    description:
      "Microsoft's free AI assistant powered by GPT-4. Integrated into Windows, Edge, and Microsoft 365. Free access to GPT-4 with image generation via DALL·E.",
    plans: [
      { name: "Free",        price: "$0/mo — GPT-4 + DALL·E free", colorClass: "green"  },
      { name: "Copilot Pro", price: "$20/mo — M365 integration",    colorClass: "yellow" },
    ],
    links: {
      website: "https://copilot.microsoft.com",
      ios:     "https://apps.apple.com/app/microsoft-copilot/id6472538445",
      android: "https://play.google.com/store/apps/details?id=com.microsoft.copilot",
    },
  },

  // ══════════════════════ WRITING ══════════════════════
  {
    id: "jasper",
    name: "Jasper AI",
    tagline: "AI content & copywriting platform",
    category: "writing",
    pricing: "paid",
    logo: "🖊️",
    description:
      "Enterprise-grade AI writing tool for marketing teams. Create blog posts, ads, emails, and social copy with brand voice consistency and SEO optimization.",
    plans: [
      { name: "Creator",  price: "$49/mo — 1 user, 1 brand voice", colorClass: "yellow" },
      { name: "Pro",      price: "$69/mo — Collaboration + SEO",    colorClass: "red"    },
      { name: "Business", price: "Custom pricing",                   colorClass: "red"    },
    ],
    links: {
      website: "https://www.jasper.ai",
      noapp:   "https://www.jasper.ai",
    },
  },
  {
    id: "grammarly",
    name: "Grammarly",
    tagline: "AI grammar & writing assistant",
    category: "writing",
    pricing: "freemium",
    logo: "✅",
    description:
      "AI-powered writing assistant that checks grammar, clarity, tone, and style. Works across browsers, docs, and apps. Includes GrammarlyGO for generative writing.",
    plans: [
      { name: "Free",     price: "$0/mo — Basic grammar check",  colorClass: "green"  },
      { name: "Premium",  price: "$12/mo — Full suggestions",    colorClass: "yellow" },
      { name: "Business", price: "$15/user/mo",                  colorClass: "red"    },
    ],
    links: {
      website: "https://www.grammarly.com",
      ios:     "https://apps.apple.com/app/grammarly-keyboard/id1158877342",
      android: "https://play.google.com/store/apps/details?id=com.grammarly.android.keyboard",
    },
  },
  {
    id: "copyai",
    name: "Copy.ai",
    tagline: "AI for marketing copy & content",
    category: "writing",
    pricing: "freemium",
    logo: "📋",
    description:
      "Generate marketing copy, emails, social posts, and long-form content with AI. 90+ templates and workflow automation for sales and marketing teams.",
    plans: [
      { name: "Free", price: "$0/mo — 2,000 words/mo",   colorClass: "green"  },
      { name: "Pro",  price: "$49/mo — Unlimited words",  colorClass: "yellow" },
      { name: "Team", price: "$249/mo — 5 users",         colorClass: "red"    },
    ],
    links: {
      website: "https://www.copy.ai",
      noapp:   "https://www.copy.ai",
    },
  },
  {
    id: "notionai",
    name: "Notion AI",
    tagline: "AI writing inside your notes",
    category: "writing",
    pricing: "freemium",
    logo: "📓",
    description:
      "AI built into your Notion workspace. Summarize notes, draft documents, fix writing, generate action items from meetings, and translate content instantly.",
    plans: [
      { name: "Notion Free", price: "$0/mo — Limited AI responses", colorClass: "green"  },
      { name: "AI Add-on",   price: "$10/mo per member",            colorClass: "yellow" },
      { name: "Business",    price: "$18/user/mo + AI",             colorClass: "red"    },
    ],
    links: {
      website: "https://www.notion.so/product/ai",
      ios:     "https://apps.apple.com/app/notion/id1232780281",
      android: "https://play.google.com/store/apps/details?id=notion.id",
    },
  },
  {
    id: "rytr",
    name: "Rytr",
    tagline: "Budget AI writing assistant",
    category: "writing",
    pricing: "freemium",
    logo: "✒️",
    description:
      "Affordable AI writing tool supporting 40+ use cases and 30+ languages. Great for individuals and small teams needing quick content generation without a large budget.",
    plans: [
      { name: "Free",      price: "$0/mo — 10k chars/mo",   colorClass: "green"  },
      { name: "Saver",     price: "$9/mo — 100k chars/mo",  colorClass: "yellow" },
      { name: "Unlimited", price: "$29/mo",                  colorClass: "red"    },
    ],
    links: {
      website: "https://rytr.me",
      noapp:   "https://rytr.me",
    },
  },

  // ══════════════════════ IMAGE ══════════════════════
  {
    id: "midjourney",
    name: "Midjourney",
    tagline: "Premium AI art generation",
    category: "image",
    pricing: "paid",
    logo: "🌌",
    description:
      "Industry-leading AI image generator known for stunning artistic quality. Creates photorealistic and stylized artwork from text prompts via web and Discord.",
    plans: [
      { name: "Basic",    price: "$10/mo — 200 images/mo", colorClass: "yellow" },
      { name: "Standard", price: "$30/mo — 15hr fast GPU", colorClass: "yellow" },
      { name: "Pro",      price: "$60/mo — Stealth mode",  colorClass: "red"    },
    ],
    links: {
      website: "https://www.midjourney.com",
      noapp:   "https://www.midjourney.com",
    },
  },
  {
    id: "dalle",
    name: "DALL·E 3",
    tagline: "OpenAI's image generator",
    category: "image",
    pricing: "freemium",
    logo: "🎭",
    description:
      "OpenAI's DALL·E 3 creates highly accurate images from detailed text descriptions. Free via Bing Image Creator or integrated into ChatGPT Plus.",
    plans: [
      { name: "Free (Bing)",  price: "$0/mo — Via Bing Creator",   colorClass: "green"  },
      { name: "ChatGPT Plus", price: "$20/mo — Integrated access",  colorClass: "yellow" },
      { name: "API",          price: "$0.04–$0.12 per image",       colorClass: "red"    },
    ],
    links: {
      website: "https://openai.com/dall-e-3",
      ios:     "https://apps.apple.com/app/chatgpt/id6448311069",
    },
  },
  {
    id: "stable-diffusion",
    name: "Stable Diffusion",
    tagline: "Open-source image AI",
    category: "image",
    pricing: "free",
    logo: "🌀",
    description:
      "Powerful open-source image generation model you can run locally or via hosted platforms. Full control over outputs, no content restrictions on self-hosted setups.",
    plans: [
      { name: "Open Source", price: "$0 — Self-hosted free",    colorClass: "green"  },
      { name: "DreamStudio", price: "Pay-per-use credits",       colorClass: "yellow" },
    ],
    links: {
      website: "https://stability.ai",
      noapp:   "https://dreamstudio.ai",
    },
  },
  {
    id: "canva",
    name: "Canva AI",
    tagline: "Design + AI generation",
    category: "image",
    pricing: "freemium",
    logo: "🖌️",
    description:
      "Canva's AI suite includes Magic Media (text-to-image), Magic Edit, Background Remover, and AI design suggestions. Perfect for non-designers creating polished visuals.",
    plans: [
      { name: "Free",  price: "$0/mo — Limited AI credits",  colorClass: "green"  },
      { name: "Pro",   price: "$15/mo — 500 AI credits/mo",  colorClass: "yellow" },
      { name: "Teams", price: "$10/user/mo",                  colorClass: "red"    },
    ],
    links: {
      website: "https://www.canva.com",
      ios:     "https://apps.apple.com/app/canva-design-photo-video/id897446215",
      android: "https://play.google.com/store/apps/details?id=com.canva.editor",
    },
  },
  {
    id: "firefly",
    name: "Adobe Firefly",
    tagline: "Adobe's generative AI for creatives",
    category: "image",
    pricing: "freemium",
    logo: "🔥",
    description:
      "Adobe's commercially safe AI image generator. Integrated into Photoshop, Illustrator, and Express. Generate images, fill selections, and apply text effects with AI.",
    plans: [
      { name: "Free",          price: "$0/mo — 25 credits/mo",  colorClass: "green"  },
      { name: "Premium",       price: "$4.99/mo — 100 credits", colorClass: "yellow" },
      { name: "Creative Cloud", price: "$54.99/mo — All apps",  colorClass: "red"    },
    ],
    links: {
      website: "https://firefly.adobe.com",
      ios:     "https://apps.apple.com/app/adobe-express/id1473332082",
    },
  },

  // ══════════════════════ VIDEO ══════════════════════
  {
    id: "runway",
    name: "Runway ML",
    tagline: "AI video generation & editing",
    category: "video",
    pricing: "freemium",
    logo: "🎞️",
    description:
      "Professional AI video tool used in Hollywood productions. Gen-2 generates video from text or images. Features inpainting, background removal, and motion brush.",
    plans: [
      { name: "Free",     price: "$0/mo — 125 credits",   colorClass: "green"  },
      { name: "Standard", price: "$15/mo — 625 credits",  colorClass: "yellow" },
      { name: "Pro",      price: "$35/mo — 2250 credits", colorClass: "red"    },
    ],
    links: {
      website: "https://runwayml.com",
      ios:     "https://apps.apple.com/app/runway-ai-video-generator/id1665024375",
    },
  },
  {
    id: "synthesia",
    name: "Synthesia",
    tagline: "AI avatar video creation",
    category: "video",
    pricing: "paid",
    logo: "🎙️",
    description:
      "Create professional AI avatar videos without cameras or studios. Choose from 160+ avatars and 120+ languages for training, marketing, or explainer videos.",
    plans: [
      { name: "Starter",    price: "$29/mo — 120 min video/yr", colorClass: "yellow" },
      { name: "Creator",    price: "$89/mo — 360 min/yr",       colorClass: "red"    },
      { name: "Enterprise", price: "Custom",                     colorClass: "red"    },
    ],
    links: {
      website: "https://www.synthesia.io",
      noapp:   "https://www.synthesia.io",
    },
  },
  {
    id: "descript",
    name: "Descript",
    tagline: "Edit video by editing text",
    category: "video",
    pricing: "freemium",
    logo: "📹",
    description:
      "Revolutionary video editor where you edit by editing the transcript. Features overdub voice cloning, filler word removal, screen recording, and podcast tools.",
    plans: [
      { name: "Free",     price: "$0/mo — 1hr transcription", colorClass: "green"  },
      { name: "Creator",  price: "$24/mo — 10hr/mo",          colorClass: "yellow" },
      { name: "Business", price: "$40/mo",                    colorClass: "red"    },
    ],
    links: {
      website: "https://www.descript.com",
      noapp:   "https://www.descript.com/download",
    },
  },
  {
    id: "heygen",
    name: "HeyGen",
    tagline: "AI video with custom avatars",
    category: "video",
    pricing: "freemium",
    logo: "👤",
    description:
      "Create personalized AI videos with your own avatar and voice clone. Supports 40+ languages for instant video translation. Popular for sales outreach and training videos.",
    plans: [
      { name: "Free",     price: "$0/mo — 1 min video/mo",  colorClass: "green"  },
      { name: "Creator",  price: "$29/mo — 15 min/mo",      colorClass: "yellow" },
      { name: "Business", price: "$89/mo — Unlimited",      colorClass: "red"    },
    ],
    links: {
      website: "https://www.heygen.com",
      noapp:   "https://www.heygen.com",
    },
  },
  {
    id: "luma",
    name: "Luma Dream Machine",
    tagline: "Realistic AI video from text/image",
    category: "video",
    pricing: "freemium",
    logo: "🌙",
    description:
      "Generate high-quality, realistic video clips from text prompts or images. Known for smooth motion and photorealistic quality. Great for cinematic B-roll and visual effects.",
    plans: [
      { name: "Free",     price: "$0/mo — 30 generations/mo",  colorClass: "green"  },
      { name: "Standard", price: "$29.99/mo — 120 gens",       colorClass: "yellow" },
      { name: "Pro",      price: "$99.99/mo — 400 gens",       colorClass: "red"    },
    ],
    links: {
      website: "https://lumalabs.ai/dream-machine",
      noapp:   "https://lumalabs.ai/dream-machine",
    },
  },

  // ══════════════════════ CODING ══════════════════════
  {
    id: "github-copilot",
    name: "GitHub Copilot",
    tagline: "AI pair programmer by GitHub",
    category: "coding",
    pricing: "freemium",
    logo: "🐙",
    description:
      "AI code completion integrated into VS Code, JetBrains, and more. Suggests whole lines, functions, and tests. The most widely used AI coding assistant.",
    plans: [
      { name: "Free",       price: "$0/mo — 2000 completions/mo", colorClass: "green"  },
      { name: "Individual", price: "$10/mo — Unlimited",          colorClass: "yellow" },
      { name: "Business",   price: "$19/user/mo",                 colorClass: "red"    },
    ],
    links: {
      website: "https://github.com/features/copilot",
      noapp:   "https://github.com/features/copilot",
    },
  },
  {
    id: "cursor",
    name: "Cursor",
    tagline: "AI-first code editor",
    category: "coding",
    pricing: "freemium",
    logo: "⚡",
    description:
      "VS Code fork with AI superpowers. Chat with your codebase, apply AI edits across files, and get multi-line completions. Uses GPT-4 and Claude models.",
    plans: [
      { name: "Hobby",    price: "$0/mo — 2000 completions", colorClass: "green"  },
      { name: "Pro",      price: "$20/mo — Unlimited",       colorClass: "yellow" },
      { name: "Business", price: "$40/user/mo",              colorClass: "red"    },
    ],
    links: {
      website: "https://cursor.sh",
      noapp:   "https://cursor.sh",
    },
  },
  {
    id: "codeium",
    name: "Codeium",
    tagline: "Free AI code completion",
    category: "coding",
    pricing: "free",
    logo: "🟢",
    description:
      "Completely free AI code completion for individual developers. Supports 70+ languages and 40+ editors. No usage limits — a compelling Copilot alternative.",
    plans: [
      { name: "Individual", price: "$0 — Forever free",        colorClass: "green"  },
      { name: "Teams",      price: "$12/user/mo — Enterprise", colorClass: "yellow" },
    ],
    links: {
      website: "https://codeium.com",
      noapp:   "https://codeium.com/download",
    },
  },
  {
    id: "replit",
    name: "Replit AI",
    tagline: "Cloud coding + AI assistant",
    category: "coding",
    pricing: "freemium",
    logo: "🔵",
    description:
      "Browser-based IDE with AI code generation, debugging, and explanations. Build and deploy apps directly from the browser. AI Ghostwriter generates full programs from descriptions.",
    plans: [
      { name: "Free", price: "$0/mo — Basic AI access",    colorClass: "green"  },
      { name: "Core", price: "$20/mo — Full AI + deploys", colorClass: "yellow" },
    ],
    links: {
      website: "https://replit.com",
      ios:     "https://apps.apple.com/app/replit-code-anything/id1614022293",
      android: "https://play.google.com/store/apps/details?id=com.replit.app",
    },
  },
  {
    id: "v0",
    name: "v0 by Vercel",
    tagline: "AI UI component generator",
    category: "coding",
    pricing: "freemium",
    logo: "▲",
    description:
      "Generate React/Next.js UI components from text prompts. Creates shadcn/ui-compatible code you can copy, deploy, or iterate on. Ideal for rapid frontend prototyping.",
    plans: [
      { name: "Free",    price: "$0/mo — Limited generations", colorClass: "green"  },
      { name: "Premium", price: "$20/mo — More generations",   colorClass: "yellow" },
    ],
    links: {
      website: "https://v0.dev",
      noapp:   "https://v0.dev",
    },
  },

  // ══════════════════════ PRODUCTIVITY ══════════════════════
  {
    id: "otter",
    name: "Otter.ai",
    tagline: "AI meeting transcription",
    category: "productivity",
    pricing: "freemium",
    logo: "🦦",
    description:
      "Real-time meeting transcription with speaker identification. Integrates with Zoom, Google Meet, and Teams. Generates meeting summaries and searchable notes automatically.",
    plans: [
      { name: "Free",     price: "$0/mo — 300 min/mo",      colorClass: "green"  },
      { name: "Pro",      price: "$16.99/mo — 1200 min/mo", colorClass: "yellow" },
      { name: "Business", price: "$30/user/mo",              colorClass: "red"    },
    ],
    links: {
      website: "https://otter.ai",
      ios:     "https://apps.apple.com/app/otter-voice-meeting-notes/id1179357502",
      android: "https://play.google.com/store/apps/details?id=com.aisense.otter",
    },
  },
  {
    id: "zapier",
    name: "Zapier AI",
    tagline: "AI-powered workflow automation",
    category: "productivity",
    pricing: "freemium",
    logo: "⚙️",
    description:
      "Automate tasks between 6,000+ apps with AI-powered workflow builder. Describe automations in plain English and let AI create the Zap. Includes AI Actions and chatbot creation.",
    plans: [
      { name: "Free",         price: "$0/mo — 100 tasks/mo",  colorClass: "green"  },
      { name: "Professional", price: "$29.99/mo — 750 tasks", colorClass: "yellow" },
      { name: "Team",         price: "$103.50/mo",            colorClass: "red"    },
    ],
    links: {
      website: "https://zapier.com",
      noapp:   "https://zapier.com",
    },
  },
  {
    id: "reclaim",
    name: "Reclaim AI",
    tagline: "Smart AI calendar scheduling",
    category: "productivity",
    pricing: "freemium",
    logo: "📅",
    description:
      "AI scheduling assistant that automatically finds the best time for tasks, habits, and meetings on your calendar. Defends focus time and syncs across team schedules.",
    plans: [
      { name: "Free",     price: "$0/mo — 3 tasks",             colorClass: "green"  },
      { name: "Starter",  price: "$10/mo — Unlimited tasks",    colorClass: "yellow" },
      { name: "Business", price: "$15/user/mo",                 colorClass: "red"    },
    ],
    links: {
      website: "https://reclaim.ai",
      noapp:   "https://reclaim.ai",
    },
  },
  {
    id: "fireflies",
    name: "Fireflies.ai",
    tagline: "AI meeting notes & CRM insights",
    category: "productivity",
    pricing: "freemium",
    logo: "🦋",
    description:
      "AI meeting assistant that auto-joins calls, transcribes, summarizes, and tracks action items. Search across meeting history and integrate with 40+ CRM and productivity tools.",
    plans: [
      { name: "Free",     price: "$0/mo — 800 min storage",   colorClass: "green"  },
      { name: "Pro",      price: "$18/mo — Unlimited storage", colorClass: "yellow" },
      { name: "Business", price: "$29/mo",                    colorClass: "red"    },
    ],
    links: {
      website: "https://fireflies.ai",
      ios:     "https://apps.apple.com/app/fireflies-ai-notes-assistant/id1497666792",
    },
  },
  {
    id: "mem",
    name: "Mem AI",
    tagline: "AI-powered knowledge base",
    category: "productivity",
    pricing: "freemium",
    logo: "🧩",
    description:
      "AI note-taking app that automatically connects related notes and surfaces relevant information. Chat with your notes, auto-organize thoughts, and build a second brain.",
    plans: [
      { name: "Free", price: "$0/mo — Basic features",  colorClass: "green"  },
      { name: "Pro",  price: "$14.99/mo — Full AI",     colorClass: "yellow" },
    ],
    links: {
      website: "https://mem.ai",
      ios:     "https://apps.apple.com/app/mem-ai-notes/id1584543979",
    },
  },

  // ══════════════════════ AUDIO ══════════════════════
  {
    id: "elevenlabs",
    name: "ElevenLabs",
    tagline: "Hyper-realistic AI voice synthesis",
    category: "audio",
    pricing: "freemium",
    logo: "🎤",
    description:
      "Industry-leading AI voice generator with voice cloning. Convert text to ultra-realistic speech in 30+ languages. Used for audiobooks, podcasts, voiceovers, and dubbing.",
    plans: [
      { name: "Free",    price: "$0/mo — 10k chars/mo",    colorClass: "green"  },
      { name: "Starter", price: "$5/mo — 30k chars/mo",   colorClass: "yellow" },
      { name: "Creator", price: "$22/mo — 100k chars/mo", colorClass: "red"    },
    ],
    links: {
      website: "https://elevenlabs.io",
      ios:     "https://apps.apple.com/app/elevenlabs/id1670324407",
      android: "https://play.google.com/store/apps/details?id=io.elevenlabs.app",
    },
  },
  {
    id: "suno",
    name: "Suno AI",
    tagline: "Generate full songs with AI",
    category: "audio",
    pricing: "freemium",
    logo: "🎼",
    description:
      "Create full original songs with vocals and music from a text prompt. Specify genre, mood, and lyrics. Generates studio-quality audio in seconds — no musical training required.",
    plans: [
      { name: "Free",    price: "$0/mo — 50 credits/day",    colorClass: "green"  },
      { name: "Pro",     price: "$10/mo — 2500 credits/mo",  colorClass: "yellow" },
      { name: "Premier", price: "$30/mo — 10k credits/mo",   colorClass: "red"    },
    ],
    links: {
      website: "https://suno.ai",
      ios:     "https://apps.apple.com/app/suno-make-and-explore-music/id6480136315",
      android: "https://play.google.com/store/apps/details?id=com.suno.android",
    },
  },
  {
    id: "whisper",
    name: "Whisper (OpenAI)",
    tagline: "Open-source speech-to-text",
    category: "audio",
    pricing: "free",
    logo: "🔊",
    description:
      "OpenAI's open-source speech recognition model. Transcribes audio in 99 languages with remarkable accuracy. Free to run locally; available via API at low cost.",
    plans: [
      { name: "Open Source", price: "$0 — Run locally free",       colorClass: "green"  },
      { name: "API",         price: "$0.006/min of audio",          colorClass: "yellow" },
    ],
    links: {
      website: "https://openai.com/research/whisper",
      noapp:   "https://github.com/openai/whisper",
    },
  },
  {
    id: "udio",
    name: "Udio",
    tagline: "AI music creation studio",
    category: "audio",
    pricing: "freemium",
    logo: "🎹",
    description:
      "Create high-quality music across any genre with detailed prompting. Offers verse/chorus structure control, audio continuation, and stem separation. Great Suno alternative.",
    plans: [
      { name: "Free",     price: "$0/mo — 10 songs/day",  colorClass: "green"  },
      { name: "Standard", price: "$10/mo — 1200 credits", colorClass: "yellow" },
      { name: "Pro",      price: "$30/mo — 4800 credits", colorClass: "red"    },
    ],
    links: {
      website: "https://www.udio.com",
      noapp:   "https://www.udio.com",
    },
  },

  // ══════════════════════ RESEARCH ══════════════════════
  {
    id: "elicit",
    name: "Elicit",
    tagline: "AI research assistant for papers",
    category: "research",
    pricing: "freemium",
    logo: "📚",
    description:
      "AI research tool that finds, summarizes, and extracts data from 125M+ academic papers. Automate literature reviews and extract key findings without reading everything.",
    plans: [
      { name: "Free",       price: "$0/mo — 5 papers/search", colorClass: "green"  },
      { name: "Plus",       price: "$12/mo — Unlimited",      colorClass: "yellow" },
      { name: "Enterprise", price: "Custom",                   colorClass: "red"    },
    ],
    links: {
      website: "https://elicit.com",
      noapp:   "https://elicit.com",
    },
  },
  {
    id: "consensus",
    name: "Consensus",
    tagline: "Evidence-based AI research search",
    category: "research",
    pricing: "freemium",
    logo: "🔍",
    description:
      "Search and extract findings from 200M+ scientific papers. Get AI-generated consensus summaries and see what the research actually says on any topic.",
    plans: [
      { name: "Free",       price: "$0/mo — 20 searches/mo", colorClass: "green"  },
      { name: "Premium",    price: "$11.99/mo — Unlimited",  colorClass: "yellow" },
      { name: "Enterprise", price: "Custom",                  colorClass: "red"    },
    ],
    links: {
      website: "https://consensus.app",
      noapp:   "https://consensus.app",
    },
  },
  {
    id: "semantic-scholar",
    name: "Semantic Scholar",
    tagline: "Free AI-powered academic search",
    category: "research",
    pricing: "free",
    logo: "🎓",
    description:
      "Free AI-powered academic search engine from Allen Institute for AI. Covers 200M+ papers with AI-generated TLDRs, citation graphs, and related work recommendations.",
    plans: [
      { name: "Free", price: "$0 — Completely free",  colorClass: "green" },
      { name: "API",  price: "$0 — Free API access",  colorClass: "green" },
    ],
    links: {
      website: "https://www.semanticscholar.org",
      noapp:   "https://www.semanticscholar.org",
    },
  },
];
