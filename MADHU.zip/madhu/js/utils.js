/**
 * utils.js — Shared helper functions
 * Loaded before filters.js and render.js
 */

/**
 * Safely escape a string for HTML insertion.
 * Prevents XSS when inserting user-facing strings.
 */
function escapeHtml(str) {
  const div = document.createElement("div");
  div.appendChild(document.createTextNode(String(str)));
  return div.innerHTML;
}

/**
 * Debounce: returns a version of `fn` that only fires
 * after `delay` ms of inactivity (used for search input).
 */
function debounce(fn, delay = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

/**
 * Capitalize the first letter of a string.
 */
function capitalize(str) {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}
