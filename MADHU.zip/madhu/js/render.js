/**
 * render.js — All DOM rendering functions
 *
 * Each function writes into a specific container element.
 * Called once on DOMContentLoaded from main.js.
 */

// ────────────────────────────────────────────────────────
// Header
// ────────────────────────────────────────────────────────
function renderHeader() {
  document.getElementById("site-header").innerHTML = `
    <div class="logo">AIverse <span class="logo-sub">AI Tools Store</span></div>
    <div class="search-bar">
      <span>🔍</span>
      <input
        type="text"
        id="search-input"
        placeholder="Search tools…"
        aria-label="Search AI tools"
      />
    </div>
  `;

  document
    .getElementById("search-input")
    .addEventListener("input", debounce((e) => setQuery(e.target.value), 220));
}

// ────────────────────────────────────────────────────────
// Hero
// ────────────────────────────────────────────────────────
function renderHero() {
  document.getElementById("hero").innerHTML = `
    <div class="hero-tag">✦ Curated AI Tool Directory</div>
    <h1 class="hero-title">Discover the Best<br><em>AI Tools</em> for Everything</h1>
    <p class="hero-sub">
      Every tool rated, priced, and linked —
      website, mobile app, and pricing all in one place.
    </p>
    <div class="hero-stats">
      <div class="stat">
        <div class="stat-num">${TOOLS.length}+</div>
        <div class="stat-label">AI Tools</div>
      </div>
      <div class="stat">
        <div class="stat-num">${CATEGORIES.length}</div>
        <div class="stat-label">Categories</div>
      </div>
      <div class="stat">
        <div class="stat-num">Free &amp; Paid</div>
        <div class="stat-label">Pricing Info</div>
      </div>
    </div>
  `;
}

// ────────────────────────────────────────────────────────
// Filter Bar
// ────────────────────────────────────────────────────────
function renderFilterBar() {
  const catButtons = CATEGORIES.map(
    (cat) =>
      `<button class="filter-btn" data-cat="${cat.id}" onclick="setCategory('${cat.id}')">
        ${cat.label}
       </button>`
  ).join("");

  document.getElementById("filter-bar").innerHTML = `
    <span class="filter-label">Category:</span>
    <button class="filter-btn active" data-cat="all" onclick="setCategory('all')">All</button>
    ${catButtons}
    <div class="pricing-filter">
      <button class="price-tag free"      data-price="free"      onclick="togglePricing('free')">● Free</button>
      <button class="price-tag freemium"  data-price="freemium"  onclick="togglePricing('freemium')">● Freemium</button>
      <button class="price-tag paid"      data-price="paid"      onclick="togglePricing('paid')">● Paid</button>
    </div>
  `;
}

// ────────────────────────────────────────────────────────
// Tool Card Partials
// ────────────────────────────────────────────────────────

/** Badge showing Free / Freemium / Paid */
function renderPricingBadge(pricing) {
  const map = {
    free:     { label: "✓ Free",     cls: "free"     },
    freemium: { label: "◑ Freemium", cls: "freemium" },
    paid:     { label: "💳 Paid",    cls: "paid"     },
  };
  const { label, cls } = map[pricing] || map.freemium;
  return `<span class="pricing-badge ${cls}">${label}</span>`;
}

/** One row inside the pricing detail box */
function renderPlanRow({ name, price, colorClass }) {
  return `
    <div class="pricing-detail-row">
      <span class="plan-name">${escapeHtml(name)}</span>
      <span class="plan-price ${colorClass}">${escapeHtml(price)}</span>
    </div>
  `;
}

/** Website + app + fallback web link buttons */
function renderLinks(links) {
  const btns = [];

  if (links.website) {
    btns.push(
      `<a class="link-btn website" href="${links.website}" target="_blank" rel="noopener">
        🌐 Website
       </a>`
    );
  }
  if (links.ios) {
    btns.push(
      `<a class="link-btn app" href="${links.ios}" target="_blank" rel="noopener">
        📱 iOS App
       </a>`
    );
  }
  if (links.android) {
    btns.push(
      `<a class="link-btn app" href="${links.android}" target="_blank" rel="noopener">
        🤖 Android
       </a>`
    );
  }
  // Show "Use Web" fallback only when neither iOS nor Android links exist
  if (!links.ios && !links.android && links.noapp) {
    btns.push(
      `<a class="link-btn noapp" href="${links.noapp}" target="_blank" rel="noopener">
        🌐 Use Web (No App)
       </a>`
    );
  }

  return btns.join("");
}

// ────────────────────────────────────────────────────────
// Full Tool Card
// ────────────────────────────────────────────────────────
function renderToolCard(tool) {
  return `
    <div class="tool-card" data-tool-id="${tool.id}">
      <div class="card-top">
        <div class="tool-logo">${tool.logo}</div>
        <div class="tool-meta">
          <div class="tool-name">${escapeHtml(tool.name)}</div>
          <div class="tool-tagline">${escapeHtml(tool.tagline)}</div>
        </div>
        ${renderPricingBadge(tool.pricing)}
      </div>

      <div class="tool-desc">${escapeHtml(tool.description)}</div>

      <div class="pricing-detail">
        ${tool.plans.map(renderPlanRow).join("")}
      </div>

      <div class="card-links">
        ${renderLinks(tool.links)}
      </div>
    </div>
  `;
}

// ────────────────────────────────────────────────────────
// Category Section
// ────────────────────────────────────────────────────────
function renderCategorySection(category) {
  const tools = TOOLS.filter((t) => t.category === category.id);
  if (tools.length === 0) return "";

  const label = category.label.replace(/^\S+\s/, ""); // strip leading emoji for title

  return `
    <div class="category-section" data-cat="${category.id}">
      <div class="cat-header">
        <div class="cat-icon" style="background:${category.color}">${category.icon}</div>
        <div>
          <div class="cat-title">AI ${label}</div>
        </div>
        <span class="cat-count">${tools.length} tool${tools.length !== 1 ? "s" : ""}</span>
      </div>
      <div class="tool-grid">
        ${tools.map(renderToolCard).join("")}
      </div>
    </div>
  `;
}

// ────────────────────────────────────────────────────────
// Full Tools Container
// ────────────────────────────────────────────────────────
function renderAllTools() {
  document.getElementById("tools-container").innerHTML =
    CATEGORIES.map(renderCategorySection).join("") +
    `<div id="no-results" class="no-results">
      😕 No tools match your search. Try different keywords.
     </div>`;
}

// ────────────────────────────────────────────────────────
// Footer
// ────────────────────────────────────────────────────────
function renderFooter() {
  document.getElementById("site-footer").innerHTML = `
    <p>AIverse &copy; ${new Date().getFullYear()} — ${TOOLS.length} AI tools curated &amp; categorized</p>
  `;
}
