/**
 * main.js — App entry point
 *
 * Script load order (defined in index.html):
 *   1. data.js     — TOOLS & CATEGORIES arrays
 *   2. utils.js    — escapeHtml, debounce, capitalize
 *   3. filters.js  — FilterState, applyFilters, syncFilterUI
 *   4. render.js   — renderHeader, renderHero, renderAllTools, etc.
 *   5. main.js     — this file, runs after everything is loaded
 */

document.addEventListener("DOMContentLoaded", () => {
  // Render all sections
  renderHeader();
  renderHero();
  renderFilterBar();
  renderAllTools();
  renderFooter();

  // Sync button active-states with initial FilterState
  syncFilterUI();
});
