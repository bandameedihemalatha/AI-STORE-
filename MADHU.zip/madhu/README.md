# AIverse — AI Tools Store

A fully static AI tools directory. No build tools, no frameworks — just HTML, CSS, and vanilla JS.

## Quick Start

1. Open the `aiverse/` folder in VS Code
2. Install the **Live Server** extension (recommended in `.vscode/extensions.json`)
3. Right-click `index.html` → **Open with Live Server**
4. Visit `http://localhost:5500`

## Folder Structure

```
aiverse/
├── index.html              Entry point
├── css/
│   ├── base.css            CSS variables, reset, typography
│   ├── layout.css          Header, hero, grid, category sections, footer
│   └── components.css      Cards, badges, buttons, filters, search
├── js/
│   ├── data.js             TOOLS[] and CATEGORIES[] — edit here to add tools
│   ├── utils.js            escapeHtml(), debounce(), capitalize()
│   ├── filters.js          FilterState, applyFilters(), syncFilterUI()
│   ├── render.js           renderHeader/Hero/FilterBar/ToolCard/Footer
│   └── main.js             DOMContentLoaded bootstrap
├── assets/
│   ├── icons/              Favicon, PWA icons
│   └── images/             Static images
├── pages/                  Future: individual tool detail pages
└── .vscode/
    ├── settings.json       Editor config
    └── extensions.json     Recommended extensions
```

## Adding a Tool

Edit `js/data.js` and add to the `TOOLS` array:

```js
{
  id: "tool-id",          // unique, kebab-case
  name: "Tool Name",
  tagline: "One-liner",
  category: "coding",     // must match a CATEGORIES id
  pricing: "freemium",    // "free" | "freemium" | "paid"
  logo: "🤖",
  description: "2-3 sentences about the tool.",
  plans: [
    { name: "Free",  price: "$0/mo",  colorClass: "green"  },
    { name: "Pro",   price: "$20/mo", colorClass: "yellow" },
    { name: "Biz",   price: "$50/mo", colorClass: "red"    },
  ],
  links: {
    website: "https://example.com",
    ios:     "https://apps.apple.com/...",   // optional
    android: "https://play.google.com/...",  // optional
    noapp:   "https://example.com",          // shown if no ios/android
  },
}
```

## Adding a Category

Edit `js/data.js` and add to `CATEGORIES`:

```js
{ id: "design", label: "🎨 Design", icon: "🎨", color: "rgba(255,101,132,0.12)" }
```

The renderer picks it up automatically — no other file changes needed.
